first_wish_list=['i', 'a', 'shoes', 'also', 'want', 'some']
second_wish_list=['need', 'new', 'and','i', 'buy', 'pants']

for index in range(len(first_wish_list)):
    print(first_wish_list[index],second_wish_list[index])
