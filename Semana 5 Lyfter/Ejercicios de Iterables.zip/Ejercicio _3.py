my_list = [10, 20, 30, 40, 50]

# save first and last
first_element = my_list[0]
last_element = my_list[-1]

# swap
my_list[0] = last_element
my_list[-1] = first_element

print(my_list)
