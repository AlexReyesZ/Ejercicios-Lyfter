my_string = "Chocolate cake"

# start from the last index and go backwards


for i in range(len(my_string) - 1, -1, -1):
    print(my_string[i])